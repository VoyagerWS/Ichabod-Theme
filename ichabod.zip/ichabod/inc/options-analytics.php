<?php
/**
 * Adds Google analytics Tracking Code to the wp_head() hook.
 *
 *
 * @package WordPress
 * @subpackage ichabod
 */
 
 
if ( !function_exists( 'ichabod_analytics_code' ) ) {
	
	add_action('wp_head', 'ichabod_analytics_code');
	function ichabod_analytics_code() {
			
			$analytics_code ='';
			if(ichabod_option('analytics_code') != '') {
				$analytics_code .= ichabod_option('analytics_code');
			}					
			
			//trim white space for faster page loading
		//	$custom_css_trimmed =  preg_replace( '/\s+/', ' ', $custom_css );
		
			//echo css
			$analytics_output = "<!-- Google Analytics Tracking Code -->" . $analytics_code . "<!-- End Google Analytics -->";
			
			if(!empty($analytics_code)) {
				echo $analytics_output;
			}
	}
	
}
?>
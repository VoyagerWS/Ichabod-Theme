<?php 





add_action('add_meta_boxes', 'team_social_box');


function team_social_box(){
	add_meta_box(
		'team_social_box',
		__('Social Media', 'myplugin_textdomain'),
		'team_social_box_content',
		'team',
		'normal',
		'high'
		);
}

//add form to Social Media

function team_social_box_content($post){
	wp_nonce_field(plugin_basename(__FILE__), 'team_social_box_content_nonce');
	echo '<p><label for="social_details_fb">Facebook:</label>';
	echo '<input type="text" id="social_details_fb" name="social_details_fb" placeholder="Enter Facebook URL"></p>';

	echo '<p><label for="social_details_twitter">Twitter:</label>';
	echo '<input type="text" id="social_details_twitter" name="social_details_twitter" placeholder="Enter Twitter URL"></p>';

	echo '<p><label for="social_details_google">Google+:</label>';
	echo '<input type="text" id="social_details_google" name="social_details_google" placeholder="Enter Google+ URL"></p>';

	echo '<p><label for="social_details_linkedin">Linkedin:</label>';
	echo '<input type="text" id="social_details_linkedin" name="social_details_linkedin" placeholder="Enter Linkedin URL"></p>';

	echo '<p><label for="social_details_pinterest>Pinterest:</label>';
	echo '<input type="text" id="social_details_pinterest" name="social_details_pinterest" placeholder="Enter Pinterest URL"></p>';

	echo '<p><label for="social_details_instagram>Instagram:</label>';
	echo '<input type="text" id="social_details_instagram" name="social_details_instagram" placeholder="Enter Instagram URL"></p>';
}

//premissions for Social meta box and allows us to save changes

add_action('save_post', 'team_social_box_save');

function team_social_box_save($post_id){
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;
	if (!wp_verify_nonce($_POST['team_social_box_content_nonce'], plugin_basename( __FILE__ )))
		return;
	if ('page' == $_POST['post_type']){
		if (!current_user_can('edit_page',$post_id))
			return;	
	}else {
		if (!current_user_can('edit_post', $post_id))
			return;
	}
$social_details_fb = $_POST['social_details_fb'];
update_post_meta($post_id, 'social_details_fb', $social_details_fb);

$social_details_twitter = $_POST['social_details_twitter'];
update_post_meta($post_id, 'social_details_twitter', $social_details_twitter);

$social_details_google = $_POST['social_details_google'];
update_post_meta($post_id, 'social_details_google', $social_details_google);

$social_details_linkedin = $_POST['social_details_linkedin'];
update_post_meta($post_id, 'social_details_linkedin', $social_details_linkedin);

$social_details_pinterest = $_POST['social_details_pinterest'];
update_post_meta($post_id, 'social_details_pinterest', $social_details_pinterest);

$social_details_instagram = $_POST['social_details_instagram'];
update_post_meta($post_id, 'social_details_instagram', $social_details_instagram);

}


 ?>
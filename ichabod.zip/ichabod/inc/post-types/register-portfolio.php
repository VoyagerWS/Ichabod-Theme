<?php 

$portfolio = new CPT(array(
    'post_type_name' => 'portfolio',
    'singular' => __('Portfolio', 'ichabod'),
    'plural' => __('Portfolio', 'ichabod'),
    'slug' => 'portfolio'
),
array(
    'supports' => array('title','author','excerpt', 'editor', 'thumbnail', 'comments')
)
);

$portfolio->register_taxonomy(array(
    'taxonomy_name' => 'portfolio_tags',
    'singular' => __('Portfolio Tags', 'ichabod'),
    'plural' => __('Portfolio Tags', 'ichabod'),
    'slug' => 'portfolio-tag'
));


 ?>
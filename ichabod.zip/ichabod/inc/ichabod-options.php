<?php
/**
 * @package ichabod
 */
 
if ( ! function_exists('ichabod_option') ) {
	function ichabod_option($id, $fallback = false, $param = false ) {
		global $ichabod_option;
		if ( $fallback == false ) $fallback = '';
		$output = ( isset($ichabod_option[$id]) && $ichabod_option[$id] !== '' ) ? $ichabod_option[$id] : $fallback;
		if ( !empty($ichabod_option[$id]) && $param ) {
			$output = $ichabod_option[$id][$param];
		}
		return $output;
	}
}
?>

<?php
/**
 * Template Name: Team
 * The template for displaying all pages.
 *
 *
 * @package ichabod
 */

get_header(); ?>

<div class="container">
	<div class="row">

	<div id="primary" class="col-md-12 col-lg-12">
		<main id="main" class="site-main" role="main">

<?php
				if (ichabod_option('team_filter_switch') == '1') {
 
				    $terms = get_terms("team_tags");
				    $count = count($terms);
				    $filter_btn_size = ichabod_option('team_filter_size');
				    $filter_btn_color = ichabod_option('team_filter_color');
				    echo '<div id="filters" class="btn-group btn-group-'.$filter_btn_size.'">';
				    echo '<button type="button" class="btn btn-'.$filter_btn_color.'" data-filter="*">'. __('All', 'ichabod') .'</button>';
				        if ( $count > 0 )
				        {   
				            foreach ( $terms as $term ) {
				                $termname = strtolower($term->name);
				                $termname = str_replace(' ', '-', $termname);
				                echo '<button type="button" class="btn btn-'.$filter_btn_color.'" data-filter=".'.$termname.'">'.$term->name.'</button>';
				            }
				        }
				    echo "</div>";
				}
			?>

			<?php 
			// the query
			$the_query = new WP_Query( array('post_type' => 'team') ); ?>

			<?php if ( $the_query->have_posts() ) : ?>

				
				<div class="row">
					<div id="team-items">
						<!-- the loop -->
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

					  <?php
		                $terms = get_the_terms( $post->ID, 'team_tags' );
		                                     
		                if ( $terms && ! is_wp_error( $terms ) ) : 
		                    $links = array();
		 
		                    foreach ( $terms as $term ) 
		                    {
		                        $links[] = $term->name;
		                    }
		                    $links = str_replace(' ', '-', $links); 
		                    $tax = join( " ", $links );     
		                else :  
		                    $tax = '';  
		                endif;
		                ?>

		                <div class="row">
								                <!--Column count for Portfolio Options Panel-->
		                
		                <?php $col_count = ichabod_option('team_column', '3'); ?>

						<div class="col-sm-6 col-md-<?php echo $col_count; ?> item <?php echo strtolower($tax); ?>">
						<a class="thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
						<?php the_post_thumbnail(); ?>
						</a>
						<div class="caption">
							<h2><?php the_title(); ?></h2>
							<p><?php the_excerpt(); ?></p>
						</div>
						</div>
						</div>
						<?php endwhile; ?>
						<!-- end of the loop -->
					</div><!--#team-items -->
				</div><!--.row -->

				<?php wp_reset_postdata(); ?>

			<?php else : ?>
				<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
			<?php endif; ?>


		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- .row -->
</div><!-- .container -->
<?php get_footer(); ?>

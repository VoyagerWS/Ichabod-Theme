<?php 

$team = new CPT(array(
    'post_type_name' => 'team',
    'singular' => __('Team', 'ichabod'),
    'plural' => __('Team', 'ichabod'),
    'slug' => 'team'
),
array(
    'supports' => array('title','excerpt', 'editor', 'thumbnail')
)
);

$team->register_taxonomy(array(
    'taxonomy_name' => 'team_tags',
    'singular' => __('Team Tags', 'ichabod'),
    'plural' => __('Team Tags', 'ichabod'),
    'slug' => 'team-tag'
));


 ?>
<?php 

$testimonial = new CPT(array(
    'post_type_name' => 'testimonial',
    'singular' => __('Testimonial', 'ichabod'),
    'plural' => __('Testimonial', 'ichabod'),
    'slug' => 'testimonial'
),
array(
    'supports' => array('title', 'editor', 'thumbnail'),
    'menu_icon'=> 'dashicons-format-quote'
)

);




 ?>
<?php
/**
 * ichabod functions and definitions
 *
 * @package ichabod
 */


// Include the Redux theme options Framework
if ( !class_exists( 'ReduxFramework' ) ) {
	require_once( get_template_directory() . '/options/framework.php' );
}
 
// Register all the theme options
require_once( get_template_directory() . '/inc/options-config.php' );

/**
* Ichabod Global Function
 */
require get_template_directory() . '/inc/ichabod-options.php';


$widget_count = ichabod_option('footer_widgets', '3'); 



/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

if ( ! function_exists( 'ichabod_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function ichabod_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on ichabod, use a find and replace
	 * to change 'ichabbod' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'ichabbod', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'ichabbod' ),
	) );
	
		register_nav_menus( array(
		'footer-left-menu' => __( 'Footer Menu Left', 'ichabbod' ),
	) );
		register_nav_menus( array(
		'footer-right-menu' => __( 'Footer Menu Right', 'ichabbod' ),
	) );	

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link'
	) );

	// Setup the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'ichabod_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif; // ichabod_setup
add_action( 'after_setup_theme', 'ichabod_setup' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function ichabod_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar Right', 'ichabbod' ),
		'id'            => 'sidebar-right',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Sidebar Left', 'ichabbod' ),
		'id'            => 'sidebar-left',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 1', 'ichabbod' ),
		'id'            => 'footer-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 2', 'ichabbod' ),
		'id'            => 'footer-2',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 3', 'ichabbod' ),
		'id'            => 'footer-3',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );


	register_sidebar( array(
		'name'          => __( 'Footer 4', 'ichabbod' ),
		'id'            => 'footer-4',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
 
}
add_action( 'widgets_init', 'ichabod_widgets_init' );


/**
 * Allow Shortcodes in Text Widgets
 */

add_filter('widget_text', 'do_shortcode');

/**
 * Enqueue scripts and styles.
 */
function ichabod_scripts() {
	wp_enqueue_style( 'bootstrap-styles', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '3.3.5', 'all' );

	wp_enqueue_style( 'font-awesome-styles', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.3.0', 'all' );

	wp_enqueue_style( 'ichabod-style', get_stylesheet_uri() );

	wp_enqueue_script( 'respond-js', get_template_directory_uri() . '/js/respond.min.js', array(jquery), '1.4.2', true );

	wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js', array(jquery), '3.3.5', true );

	wp_enqueue_script( 'ichabod-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	wp_enqueue_script( 'isotope-js', get_template_directory_uri() . '/js/isotope.pkgd.min.js', array(), '2.2.0', true );

	wp_enqueue_script( 'image-loaded-js', get_template_directory_uri() . '/js/imagesloaded.pkgd.min.js', array(), '3.1.8', true );


	wp_enqueue_script( 'custom-js', get_template_directory_uri() . '/js/custom.js', array(), '3.3.5', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ichabod_scripts' );

/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load Bootstrap Walker Menu.
 */
require get_template_directory() . '/inc/bootstrap-walker.php';

/**
* Comments Callback.
 */
require get_template_directory() . '/inc/comments-callback.php';

/**
* Author Meta
 */
require get_template_directory() . '/inc/author-meta.php';


/**
* Team Meta
 */
require get_template_directory() . '/inc/team-meta.php';



/**
* Options CSS
 */
require get_template_directory() . '/inc/options-css.php';
/**
* Options Analytics
 */
require get_template_directory() . '/inc/options-analytics.php';
/**
* POST TYPES
 */
require get_template_directory() . '/inc/post-types/CPT.php';

require get_template_directory() . '/inc/post-types/register-portfolio.php';

require get_template_directory() . '/inc/post-types/register-team.php';

require get_template_directory() . '/inc/post-types/register-testimonial.php';




<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package ichabod
 */
?>

	</div><!-- #content -->
</div><!-- #page -->
	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="container">



<?php 
			// Widget variable from Theme Options
			$widget_count = ichabod_option('footer_widgets', '3'); ?>

			<!-- Footer Widget Area -->
			<div class="footer-widgets">
			<div class="row">
				
					<div class="col-sm-6 col-md-<?php echo $widget_count; ?>">
						<?php dynamic_sidebar( 'footer-1' ); ?>
					</div>
					<div class="col-sm-6 col-md-<?php echo $widget_count; ?>">
						<?php dynamic_sidebar( 'footer-2' ); ?>
					</div>
					<div class="col-sm-6 col-md-<?php echo $widget_count; ?>">
						<?php dynamic_sidebar( 'footer-3' ); ?>
					</div>
					<div class="col-sm-6 col-md-<?php echo $widget_count; ?>">
						<?php dynamic_sidebar( 'footer-4' ); ?>
					</div>
				
			</div><!-- .row -->
			</div>
			<!-- End Footer Widget Area -->
			</div><!-- .container -->



			<div class="bottom-footer">

			<div class="row">

				<div class="col-md-6 col-lg-6">
					<?php if(has_nav_menu('footer-left-menu','ichabbod')){ ?>
						<nav role="navigation">
								<?php wp_nav_menu(array(
									'container'       => '',
									'menu_class'      => 'footer-left-menu',
									'theme_location'  => 'footer-left-menu')
								);
								 ?>
						</nav>
						<?php } ?>
				</div>	


				<div class="col-md-6 col-lg-6">
					<?php if(has_nav_menu('footer-right-menu','ichabbod')){ ?>
						<nav role="navigation">
								<?php wp_nav_menu(array(
									'container'       => '',
									'menu_class'      => 'footer-right-menu',
									'theme_location'  => 'footer-right-menu')
								);
								 ?>
						</nav>
						<?php } ?>
				</div>				

			</div><!-- .row -->

			<div class="row">
			<div class="col-md-4 col-lg-4">
				<?php if (ichabod_option('footer_text_left') != '') { ?>
				<div class="footer-left">
					<?php echo ichabod_option('footer_text_left'); ?>
				</div>
				<?php } ?>
				
			</div>

				<div class="social-icons col-md-4 col-lg-4">
	                <?php $social_options = ichabod_option( 'social_icons' ); ?>
	                    <?php foreach ( $social_options as $key => $value ) {
	                        if ( $value ) { ?>
	                            <a href="<?php echo $value; ?>" title="<?php echo $key; ?>" target="_blank">
	                                <i class="fa fa-<?php echo $key; ?>"></i>
	                            </a>
	                        <?php }
	                    } ?>
                </div><!-- .social-icons -->
		

			<div class="col-md-4 col-lg-4">
				<?php if (ichabod_option('footer_text_right') != '') { ?>
				<div class="footer-right-menu">
					<?php echo ichabod_option('footer_text_right'); ?>
				</div>
				<?php } ?>	
			</div>
 
		</div><!-- .row -->
	</div><!-- .bottom-footer -->
		
	</footer><!-- #colophon -->


<?php wp_footer(); ?>

</body>
</html>
